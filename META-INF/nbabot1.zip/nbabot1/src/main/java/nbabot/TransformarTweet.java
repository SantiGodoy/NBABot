package nbabot;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import twitter4j.ResponseList;
import twitter4j.Status;

public class TransformarTweet extends AbstractMessageTransformer{
    
    public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {

    	ResponseList list =  (ResponseList) message.getPayload();
    	Status st = (Status)list.get(0);
    	String jugador = st.getText().substring(9);
    	
    	return jugador;
    }
}
