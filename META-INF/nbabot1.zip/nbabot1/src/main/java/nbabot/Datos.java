package nbabot;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class Datos {
	private CumulativePlayerStats cumulativeplayerstats;
	
	public Datos() {}

	public CumulativePlayerStats getCumulativeplayerstats() {
		return cumulativeplayerstats;
	}

	public void setCumulativeplayerstats(CumulativePlayerStats cumulativeplayerstats) {
		this.cumulativeplayerstats = cumulativeplayerstats;
	}
}
