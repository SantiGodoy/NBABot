package nbabot;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class CumulativePlayerStats {
	private String lastUpdatedOn;
	private List<Map<String, Object>> playerstatsentry;
	public CumulativePlayerStats() {
	}
	public String getLastUpdatedOn() {
		return lastUpdatedOn;
	}
	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}
	public List<Map<String, Object>> getPlayerstatsentry() {
		return playerstatsentry;
	}
	public void setPlayerstatsentry(List<Map<String, Object>> playerstatsentry) {
		this.playerstatsentry = playerstatsentry;
	}

}
