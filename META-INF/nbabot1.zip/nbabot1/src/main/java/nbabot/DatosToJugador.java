package nbabot;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class DatosToJugador extends AbstractMessageTransformer {
	 
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		Datos datos = (Datos)message.getPayload();
		Jugador jugador = new Jugador();
		CumulativePlayerStats cps = datos.getCumulativeplayerstats();
		List<Map<String, Object>> stats = cps.getPlayerstatsentry();
		
		LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) stats.get(0);
		LinkedHashMap<String, String> player = ((LinkedHashMap<String, String>)map.get("player"));
		jugador.setFirstName(player.get("FirstName"));
		jugador.setLastName(player.get("LastName"));
		jugador.setJerseyNumber(player.get("JerseyNumber"));
		jugador.setPosition(player.get("Position"));
		
		LinkedHashMap<String, String> team = ((LinkedHashMap<String, String>)map.get("team"));
		jugador.setCity(team.get("City"));
		jugador.setName(team.get("Name"));
		
		LinkedHashMap<String, LinkedHashMap<String, String>> playerstats = 
				(LinkedHashMap<String, LinkedHashMap<String, String>>)map.get("stats");
		jugador.setGamesPlayed(playerstats.get("GamesPlayed").get("#text"));
		jugador.setRebPerGame(playerstats.get("RebPerGame").get("#text"));
		jugador.setPtsPerGame(playerstats.get("PtsPerGame").get("#text"));
		jugador.setAstPerGame(playerstats.get("AstPerGame").get("#text"));
		jugador.setBlkPerGame(playerstats.get("BlkPerGame").get("#text"));
		jugador.setStlPerGame(playerstats.get("StlPerGame").get("#text"));
		Float minutos = Float.parseFloat(((playerstats.get("MinSecondsPerGame").get("#text"))))/60;
		jugador.setMinSecondsPerGame(String.format("%.02f", minutos));

		
		return jugador;
	}	
}
