package nbabot;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class Jugador {
	
	private String FirstName;
	private String LastName;
	private String JerseyNumber;
	private String RebPerGame;
	private String AstPerGame;
	private String PtsPerGame;
	private String StlPerGame;
	private String BlkPerGame;
	private String GamesPlayed;
	private String MinSecondsPerGame;
	private String City;
	private String Name;
	private String Position;
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getJerseyNumber() {
		return JerseyNumber;
	}
	public void setJerseyNumber(String jerseyNumber) {
		JerseyNumber = jerseyNumber;
	}
	public String getRebPerGame() {
		return RebPerGame;
	}
	public void setRebPerGame(String rebPerGame) {
		RebPerGame = rebPerGame;
	}
	public String getAstPerGame() {
		return AstPerGame;
	}
	public void setAstPerGame(String astPerGame) {
		AstPerGame = astPerGame;
	}
	public String getPtsPerGame() {
		return PtsPerGame;
	}
	public void setPtsPerGame(String ptsPerGame) {
		PtsPerGame = ptsPerGame;
	}
	public String getStlPerGame() {
		return StlPerGame;
	}
	public void setStlPerGame(String stlPerGame) {
		StlPerGame = stlPerGame;
	}
	public String getBlkPerGame() {
		return BlkPerGame;
	}
	public void setBlkPerGame(String blkPerGame) {
		BlkPerGame = blkPerGame;
	}
	public String getGamesPlayed() {
		return GamesPlayed;
	}
	public void setGamesPlayed(String gamesPlayed) {
		GamesPlayed = gamesPlayed;
	}
	public String getMinSecondsPerGame() {
		return MinSecondsPerGame;
	}
	public void setMinSecondsPerGame(String minSecondsPerGame) {
		MinSecondsPerGame = minSecondsPerGame;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPosition() {
		return Position;
	}
	public void setPosition(String position) {
		Position = position;
	}
	public Jugador() {}
	
	public String position() {
		switch(Position) {
			case "SG": return "Escolta";
			case "C": return "Pívot";
			case "PF": return "Ala-Pívot";
			case "SF": return "Alero";
			case "PG": return "Base";
			default: return "";
		}
	}
	
	public String toString() {
		return "\n" + FirstName + " " + LastName + "  " +
				"/|" + JerseyNumber + "|\\" + "\n" +
				City.toUpperCase() + " " + Name.toUpperCase() + "\n" +
				"Posición: " + position() + "\n" +
				"Partidos jugados: " + GamesPlayed + "\n\n" +
				"ESTADÍSTICAS POR PARTIDO\n" + 
				"Minutos: " + MinSecondsPerGame +
				"\nPuntos: " + PtsPerGame + 
				"\nAsistencias: " + AstPerGame +
				"\nRebotes: " + RebPerGame + 
				"\nRobos: " + StlPerGame + 
				"\nTapones: " + BlkPerGame;
	}
	
}